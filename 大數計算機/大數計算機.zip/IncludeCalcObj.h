#pragma once
#include  "CalcObj_minus.h"
#include "CalcObj_plus.h"

#include"CalcObj_pos.h"
#include "CalcObj_neg.h"

#include "CalcObj_div.h"
#include "CalcObj_multi.h"

#include "CalcObj_power.h"
#include "CalcObj_factorial.h"

#include "CalcObj_num.h"

#include "CalcObj_assign.h"
#include "CalcObj_variable.h"